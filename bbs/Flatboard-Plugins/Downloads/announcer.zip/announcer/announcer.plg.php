<?php defined("FLATBOARD_PRO") or die("Flatboard community");

function announcer_install()
{
	global $lang;
	$plugin = 'announcer';
	if (flatDB::isValidEntry('plugin', $plugin))
		return;

    $data[$plugin.'state']   	  	= true; 
    $data['banners']            = [];
	flatDB::saveEntry('plugin', $plugin, $data);
}
# remove arrays
function removeBanner($array, $item){
    if(!empty($array[$item]) || in_array($array[$item])){
         unset($array[$item]);
    }
}

function announcer_config(){
	 global $lang, $token; 
    $plugin = 'announcer';
    $out ='';
    if(User::isAdmin()){
         if (flatDB::isValidEntry('plugin', $plugin))
               $data = flatDB::readEntry('plugin', $plugin);
        if(!empty($_POST) && CSRF::check($token)){
             $data[$plugin.'state']= Util::isPOST('state') ? $_POST['state'] : ''; 
            $bannerName = Util::isPOST('bannerName') ? HTMLForm::clean( $_POST['bannerName']): uniqid();
            $bannerType =  Util::isPOST('bannerType') ? HTMLForm::clean($_POST['bannerType']) : 'success';
            $bannerText =  Util::isPOST('bannerText') ? HTMLForm::clean($_POST['bannerText']) : 'demo banner';
            $bannerDisply = Util::isPOST('bannerDisply') ? HTMLForm::clean($_POST['bannerDisply']) : 'all';
            $bannerActive = Util::isPOST('bannerActive') ? $_POST['bannerActive'] : ''; 
            $bannerOld = Util::isPOST('bannerOld') ? HTMLForm::clean($_POST['bannerOld']) : ''; 
            $bannerDelete = Util::isPOST('bannerDelete') ? $_POST['bannerDelete'] : ''; 
            $bannerEdit = Util::isPOST('bannercreate') ? $_POST['bannercreate'] : ''; 
            if($bannerDelete){
               $data['banners'][$bannerOld] = removeBanner($data['banners'], $bannerOld);
            }else{
                if($bannerEdit){
                $data['banners'][$bannerOld] = ['name'=>$bannerOld,'type'=>$bannerType, 'text'=>$bannerText, 'Display'=>$bannerDisply, 'active'=>$bannerActive];
                }else{
                $data['banners'][$bannerName] = ['name'=>$bannerName,'type'=>$bannerType, 'text'=>$bannerText, 'Display'=>$bannerDisply, 'active'=>$bannerActive];
                }
            }
                flatDB::saveEntry('plugin', $plugin, $data);
               $out .= Plugin::redirectMsg($lang['data_save'],'config.php' . DS . 'plugin' . DS . $plugin, $lang['plugin'].'&nbsp;<b>' .$lang[$plugin.'name']. '</b>');
        }else{
                $forums = flatDB::listEntry('topic');
	$forumsSelect = array('all'=>'All Pages');
	foreach($forums as $forum){
		$forumName = flatDB::readEntry('topic', $forum)['title'];
		$forumsSelect[$forum] = $forumName;
	}

        $oldBanners = array();
            
                foreach($data['banners'] as $banners){
                    if(!empty($banners)){
                        $oldBanners[$banners['name']] = $banners['name'];
                    }
                }
               $bannerTypes = array('primary'=>'primary','secondary'=>'secondary','success'=>'success', 'warning'=>'warning', 'danger'=>'danger', 'info'=>'info', 'light'=>'light', 'dark'=>'dark');
                $out .=  HTMLForm::form('config.php' . DS . 'plugin' . DS . $plugin, '
           <div class="row">
           <div class="col">
           '.HTMLForm::checkBox('state', $data[$plugin.'state']).'
           </div>
            <div class="col" id="bCreate">
           '.HTMLForm::checkBox('bannercreate').'
           </div>
           </div>
           <div class="row">
           <div class="col" id="bName">
           '.HTMLForm::text('bannerName', uniqid()).'
           </div>
              <div class="col"  id="bOld">
           '.HTMLForm::select('bannerOld', $oldBanners).'
           </div>
           <div class="col" id="bType">
           '.HTMLForm::select('bannerType',  $bannerTypes).'
           </div>
           </div>
           <div class="row">
           <div class="col" id="bDisply">
           '.HTMLForm::select('bannerDisply', $forumsSelect).'
           </div>
           <div class="col" id="bTxt">
            '.HTMLForm::text('bannerText').'
           </div>
           </div>
           <div class="row">
           <div class="col" id="bActive">
           '.HTMLForm::checkBox('bannerActive').'
           </div>
           <div class="col" id="bDelete">
           '.HTMLForm::checkBox('bannerDelete').'
           </div>
           </div>'.HTMLForm::simple_submit());
        
          
         
        }
        return $out;
    }
}
function announcer_beforeMain(){
    global $lang; 
    $plugin = 'announcer';
    $out ='';
      if (flatDB::isValidEntry('plugin', $plugin))
               $data = flatDB::readEntry('plugin', $plugin);
    if($data[$plugin.'state']){
        foreach($data['banners'] as $ban){
            if(!empty($ban) && $ban['Display'] === 'all' && $ban['active']){
                $out .= '<div id="announcer_'.$ban['name'].'" style="border-radius:1em" class="text-center alert alert-'.$ban['type'].'" role="alert">
                <h1>'.$ban['name'].'</h1>
                <p>'.$ban['text'].'</p>
                </div>';
            }elseif(!empty($ban) && $ban['Display'] === $_GET['topic'] && $ban['active']){
             $out .= '<div id="announcer_'.$ban['name'].'" style="border-radius:1em" class="text-center alert alert-'.$ban['type'].'" role="alert">
                <h1>'.$ban['name'].'</h1>
                <p>'.$ban['text'].'</p>
                </div>';
            }
        }
        return $out;
    }
}
function announcer_footerJS(){
     global $lang; 
    $plugin = 'announcer';
    $out ='';
    if (flatDB::isValidEntry('plugin', $plugin))
               $data = flatDB::readEntry('plugin', $plugin);
            if($data[$plugin.'state']){
                $out .= '<script src="'.HTML_PLUGIN_DIR.$plugin.DS.'js'.DS.$plugin.'.min.js?v=1.1.0"></script>';
            }
            return $out;
}
?>