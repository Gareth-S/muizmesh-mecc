<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Annoucer';
$lang[$plugin.'version']        = '1.1.1';
$lang[$plugin.'update']         = '2022-04-01';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Publicly announce any dangers/warnings/updates and etc. you can schedule it whenever to popup or disply forever, even on certain pages';
$lang['bannerName']             = 'Enter Banner Name';
$lang['bannerType']             = 'Select Banner Type';
$lang['bannerDisply']           = 'Select where to disply the banner(topic)';
$lang['bannerText']             = 'Enter Message';
$lang['bannerActive']           = 'Activate Banner';
$lang['bannercreate']           = 'Edit other banners';
$lang['bannerDelete']           = 'Delete Banner';
$lang['bannerOld']              = 'Select a banner to edit';
?>