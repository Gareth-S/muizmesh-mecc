<?php
/************* Informations sur le plugin OBLIGATOIRES ! ***************/
$lang[$plugin.'name']           = 'Annoucer';
$lang[$plugin.'version']        = '1.1.1';
$lang[$plugin.'update']         = '2022-04-01';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Langue  ***************/
$lang[$plugin.'description']    = 'Annoncez publiquement tout danger/avertissement/mise à jour, etc. Vous pouvez le programmer à tout moment pour qu\'il apparaisse ou s\'affiche indéfiniment, même sur certaines pages';
$lang['bannerName']             = 'Entrez le nom de la bannière';
$lang['bannerType']             = 'Sélectionnez le type de bannière';
$lang['bannerDisply']           = 'Sélectionnez où afficher la bannière (sujet)';
$lang['bannerText']             = 'Entrer un message';
$lang['bannerActive']           = 'Activer la bannière';
$lang['bannercreate']           = 'Modifier d\'autres bannières';
$lang['bannerDelete']           = 'Supprimer la bannière';
$lang['bannerOld']              = 'Sélectionnez une bannière à modifier';
?>