<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Birthday';
$lang[$plugin.'version']        = '1.0.2';
$lang[$plugin.'update']         = '2023-03-25';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = '通过在您的生日发出通知，向用户展示您的特殊日子！！！';
$lang['invalid_date']           = '失效日期';
$lang['success_date']           = '已成功添加您的生日';
$lang['intro_bday']             = '<i class="fa fa-birthday-cake"></i> 祝...生日快乐 ';
?>