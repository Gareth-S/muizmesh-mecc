<?php
/************* Informations sur le plugin OBLIGATOIRES ! ***************/
$lang[$plugin.'name']           = 'Birthday';
$lang[$plugin.'version']        = '1.0.2';
$lang[$plugin.'update']         = '2023-03-25';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Langue  ***************/
$lang[$plugin.'description']    = 'Montrez aux utilisateurs que c`est votre journée spéciale en faisant une notification le jour de votre anniversaire !!!';
$lang['invalid_date']           = 'Date invalide';
$lang['success_date']           = 'Ajouté avec succès à votre anniversaire';
$lang['intro_bday']             = '<i class="fa fa-birthday-cake"></i> Joyeux anniversaire à ';
?>