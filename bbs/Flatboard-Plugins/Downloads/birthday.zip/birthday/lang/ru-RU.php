<?php
/************* Информация о плагине ТРЕБУЕТСЯ! ***************/
$lang[$plugin.'name']           = 'Birthday';
$lang[$plugin.'version']        = '1.0.2';
$lang[$plugin.'update']         = '2023-03-25';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Язык  ***************/
$lang[$plugin.'description']    = 'Покажите пользователям, что это ваш особый день, сделав уведомление в свой день рождения!!!';
$lang['invalid_date']           = 'Недействительная дата';
$lang['success_date']           = 'Успешно добавлено в день рождения';
$lang['intro_bday']             = '<i class="fa fa-birthday-cake"></i> С днем ​​рождения ';
?>