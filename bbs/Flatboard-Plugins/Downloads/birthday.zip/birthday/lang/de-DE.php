<?php
/************* Plugin-Info ERFORDERLICH! ***************/
$lang[$plugin.'name']           = 'Birthday';
$lang[$plugin.'version']        = '1.0.2';
$lang[$plugin.'update']         = '2023-03-25';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Sprache  ***************/
$lang[$plugin.'description']    = 'Zeigen Sie den Benutzern, dass es Ihr besonderer Tag ist, indem Sie eine Benachrichtigung an Ihrem Geburtstag machen!!!';
$lang['invalid_date']           = 'Ungültiges Datum';
$lang['success_date']           = 'Geburtstag erfolgreich hinzugefügt';
$lang['intro_bday']             = '<i class="fa fa-birthday-cake"></i> Alles Gute zum Geburtstag ';
?>