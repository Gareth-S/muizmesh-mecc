<?php
/************* Informazioni sul plugin OBBLIGATORIE! ***************/
$lang[$plugin.'name']           = 'Birthday';
$lang[$plugin.'version']        = '1.0.2';
$lang[$plugin.'update']         = '2023-03-25';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Lingua  ***************/
$lang[$plugin.'description']    = 'Mostra agli utenti che è il tuo giorno speciale inviando una notifica per il tuo compleanno!!!';
$lang['invalid_date']           = 'Data non valida';
$lang['success_date']           = 'Aggiunto con successo nel tuo compleanno';
$lang['intro_bday']             = '<i class="fa fa-birthday-cake"></i> Buon compleanno a ';
?>