<div class="rules">
<h1 style="text-align:center;font-size:32px;">Rules</h1>
<ol class="list-group" style="color:black;">
  <li class="list-group-item" style="background-color:lightgray;">1. Do not cyberbully</li>
  <li class="list-group-item" style="background-color:lightgray;">2. No treat messages</li>
  <li class="list-group-item" style="background-color:lightgray;">3. Any non-related topics will be moved/removed without notice. <b>UNLESS</b> it is in any chat room.</li>
  <li class="list-group-item" style="background-color:lightgray;">4. If any of these rules are broken, will be temporary or permanently banned</li>
  <li class="list-group-item" style="background-color:lightgray;">5. Have fun</li>
</ol>
</div> 