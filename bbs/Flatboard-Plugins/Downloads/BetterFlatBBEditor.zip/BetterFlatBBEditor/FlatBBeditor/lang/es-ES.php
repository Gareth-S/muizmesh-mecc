<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Editor de FlatBB';
$lang[$plugin.'version']         = '3.1';
$lang[$plugin.'update']      	 = '2022-02-24';
$lang[$plugin.'author']          = 'Frédéric K. & SurveyBuilder-Admin';
$lang[$plugin.'author_site']     = 'https://flatboard.org';
$lang[$plugin.'author_mail']     = 'stradfred@gmail.com';
/************* Langue en ***************/
$lang[$plugin.'description']     = 'Un simple editor personalizable de BBCode, con carga de imágenes.';
$lang['idContent']               = 'área de texto de ID';
$lang['btn_toolbar']             = 'barra de herramientas';
$lang['formPosition']			 = 'Visualización de formulario';
$lang['fixed-top']				 = 'Parte superior fija';
$lang['fixed-bottom']			 = 'fondo fijo';
$lang['fixed-left']				 = 'Fijo a la izquierda';
$lang['fixed-right']			 = 'Fijo a la derecha';
/************* Toolbar ***************/
$lang['font_size']	 			 = 'Tamaño de fuente';
$lang['font_color']				 = 'Color de fuente';
$lang['bold']	 		 		 = 'Negrito';
$lang['italic']			 		 = 'Itálico';
$lang['underline']	 			 = 'Subrayar';
$lang['strike']			 		 = 'Tachado';
$lang['code']	 		 		 = 'Código';
$lang['quote']			 		 = 'Cita';
$lang['preformatted']            = 'Preformateado';
$lang['unordered_list']          = 'Lista desordenada';
$lang['ordered_list']            = 'Lista ordenada';
$lang['hide']			 		 = 'Esconder';
$lang['insert_picture_width']	 = 'Insertar una imagen con límite de tamaño';
$lang['align_center']			 = 'Alinear al centro';
$lang['align_right']	 		 = 'alinear a la derecha';
$lang['align_left']              = 'Alinear a la izquierda';
$lang['insert_picture']			 = 'Insertar una imagen';
$lang['insert_link']	 		 = 'Insertar un enlace';
$lang['insert_youtube_video']	 = 'Insertar un vídeo de Youtube';
$lang['insert_video']			 = 'Insertar una URL de video';
$lang['insert_dailymotion_video']= 'Insertar un vídeo de Dailymotion';
$lang['upload_picture']			 = 'Sube una foto';
$lang['fullscreen_editor']		 = 'Modo de pantalla completa';
$lang['insert_table']            = 'Insertar tabla';
/************* Colors ***************/
$lang['green']	  	  			 = 'Verde';
$lang['bold_blue']	  		     = 'Azul negrita';
$lang['blue']	  	  			 = 'Azul';
$lang['turquoise']	  			 = 'Turquesa';
$lang['light_green'] 			 = 'Verde claro';
$lang['bold_green']	 			 = 'Verde negrita';
$lang['yellow']	  	 			 = 'Amarillo';
$lang['orange']	  	 			 = 'naranja';
$lang['red']	  	 			 = 'Rojo';
$lang['bold_red']	 			 = 'rojo intenso';
$lang['purple']	  				 = 'Morado';
$lang['gray']	 				 = 'gris';
/************* Hidden Tag ***************/
$lang['FBBE_visible_for_all']	  = 'Visible para todos';
$lang['FBBE_visible_for_logged']  = 'Visible solo para registrados';
$lang['FBBE_visible_for_staff']	  = 'Visible solo para el personal';
$lang['FBBE_visible_for_specefic_user']= 'Visible solo para un usuario específico';
/************* Hidden msg ***************/
$lang['hide_show_more']			  = 'Mostrar más&hellip;';
$lang['hide_show_more_users']	  = 'Mostrar más para los usuarios&hellip;';
$lang['hide_show_more_staff']	  = 'Mostrar más para el personal&hellip;';
$lang['visible_for_specific_user']= 'Texto oculto para un usuario específico.';
$lang['visible_for_staff']		  = 'Texto oculto solo para el personal.';
$lang['visible_for_logged']		  = 'Debe responder/iniciar sesión antes de poder ver los datos ocultos contenidos aquí.';
?>