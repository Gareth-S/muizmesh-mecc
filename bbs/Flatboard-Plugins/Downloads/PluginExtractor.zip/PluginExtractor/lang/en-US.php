<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Plugin Extractor';
$lang[$plugin.'version']        = '0.1';
$lang[$plugin.'update']         = '2022-01-04';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Upload any plugin to extract to your forum easier';
?>
