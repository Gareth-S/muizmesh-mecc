<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Word Blocker';
$lang[$plugin.'version']        = '1.0.0';
$lang[$plugin.'update']         = '2022-02-27';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Permettre de supprimer/bloquer certains mots qui ne veulent pas être affichés sur le forum, merci de ne pas abuser de ce plugin! permettre à chacun de s\'exprimer librement.';
?>