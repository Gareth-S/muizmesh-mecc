<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Word Blocker';
$lang[$plugin.'version']        = '1.0.0';
$lang[$plugin.'update']         = '2022-02-27';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Allow to remove/block certain words that don\'t want to be shown on the forum, please don\'t misuse this plugin! allow everyone to speak freely.';
?>