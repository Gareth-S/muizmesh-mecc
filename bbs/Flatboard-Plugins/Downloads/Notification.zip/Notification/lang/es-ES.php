<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Notificación';
$lang[$plugin.'version']        = '2.2.0';
$lang[$plugin.'update']         = '2022-01-03';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = "Recibe una nueva notificación cuando estés fuera y no necesites correos electrónicos no deseados";
?>