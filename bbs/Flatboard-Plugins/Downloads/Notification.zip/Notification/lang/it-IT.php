<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Notifica';
$lang[$plugin.'version']        = '2.2.0';
$lang[$plugin.'update']         = '2022-01-03';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = "Ricevi una nuova notifica quando sei fuori e non hai bisogno di e-mail di spam";
?>