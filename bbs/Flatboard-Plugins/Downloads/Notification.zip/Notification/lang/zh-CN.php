<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = '通知';
$lang[$plugin.'version']        = '2.2.0';
$lang[$plugin.'update']         = '2022-01-03';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = "外出时收到新通知，无需垃圾邮件";
?>