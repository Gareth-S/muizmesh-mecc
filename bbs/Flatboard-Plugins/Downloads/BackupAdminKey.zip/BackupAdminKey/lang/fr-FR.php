<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = "Clé d'administration de sauvegarde";
$lang[$plugin.'version']        = '1.1.0';
$lang[$plugin.'update']         = '2022-01-05';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = "Vous avez oublié votre nom d'utilisateur et votre mot de passe administrateur? Ne vous inquiétez plus, cette clé de sauvegarde enregistrera votre nom d'utilisateur sans problème";
?>