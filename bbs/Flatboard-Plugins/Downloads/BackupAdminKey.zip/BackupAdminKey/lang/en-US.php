<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Backup Admin Key';
$lang[$plugin.'version']        = '1.1.0';
$lang[$plugin.'update']         = '2022-01-05';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Forgot your admin username and password? Well worry no more, this backup key will save your username without problems';
?>