<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Mention';
$lang[$plugin.'version']        = '1.0.7';
$lang[$plugin.'update']         = '2022-02-14';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Mention someones username using the @ symbol in chat which sets it a unique hightlighted color of choice';
?>