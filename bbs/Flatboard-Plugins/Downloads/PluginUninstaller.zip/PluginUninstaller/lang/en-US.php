<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Plugin Uninstaller';
$lang[$plugin.'version']        = '0.0.1';
$lang[$plugin.'update']         = '2022-03-02';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Uninstall any plugin and its data to save storage easier.';
?>