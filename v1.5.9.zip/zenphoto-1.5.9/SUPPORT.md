For general support about usage questions or problems please don't use issue tickets. Please visit our forum on https://forum.zenphoto.org/ instead.
