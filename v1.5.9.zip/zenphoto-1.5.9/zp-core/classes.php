<?php
/**
 * (Legacy) Loader for the root classes
 * 
 * @deprecated 
 */
require_once(dirname(__FILE__) . '/class-persistentobject.php');
require_once(dirname(__FILE__) . '/class-themeobject.php');
require_once(dirname(__FILE__) . '/class-mediaobject.php');