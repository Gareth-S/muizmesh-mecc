# Security Policy

We officially only support the lastest release version. Please report security issue via the contact page on our site:
https://www.zenphoto.org/pages/contact/
